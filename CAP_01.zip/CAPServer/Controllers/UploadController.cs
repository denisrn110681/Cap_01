﻿using System;
using System.IO;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using OfficeOpenXml;
using CAPServer.Models;


namespace CAPServer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UploadController : ControllerBase
    {
          DeliveredFile teste = new DeliveredFile();

        [HttpPost, DisableRequestSizeLimit]
        public  IActionResult Upload()
        {
            try
            {
                var file = Request.Form.Files[0];
                var folderName = Path.Combine("StaticFiles", "Images");
                var pathToSave = Path.Combine(Directory.GetCurrentDirectory(), folderName);

                if (file.Length > 0)
                {
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');
                    var fullPath = Path.Combine(pathToSave, fileName);
                    var dbPath = Path.Combine(folderName, fileName);

                    using (var memoryStream = new MemoryStream())
                    {
                         file.CopyTo(memoryStream);
                        using (var package = new ExcelPackage(memoryStream))
                        {
                            for (int i = 1; i <= package.Workbook.Worksheets.Count; i++)
                            {
                            var totalRows = package.Workbook.Worksheets[i].Dimension?.Rows;
                            var totalCollumns = package.Workbook.Worksheets[i].Dimension?.Columns;
                                for (int j = 1; j <= totalRows.Value; j++)
                                {
                                teste.DeliveryDate = package.Workbook.Worksheets[1].Cells[j, 1].Value.ToString();
                                teste.ProductDescription = package.Workbook.Worksheets[1].Cells[j, 2].Value.ToString();
                              
                                teste.Quantity = Convert.ToInt32(package.Workbook.Worksheets[1].Cells[j, 3].Value.ToString());
                                double _returnUnit = Convert.ToDouble(package.Workbook.Worksheets[1].Cells[j, 4].Value.ToString());
                                teste.UnitValue = Math.Round(_returnUnit,2);
                                
                                teste.TotalValue = teste.Quantity  * teste.UnitValue;
                                }
                            }
                        } 
                     }
                  
                    return Ok(new { dbPath });
                
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
           
            }
        }
        
    }
}