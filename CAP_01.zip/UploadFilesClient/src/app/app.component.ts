import { UserToCreate } from './_interfaces/userToCreate.model';
import { File } from './_interfaces/file.model';
import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  public isCreate: boolean;
  public name: string;
  public address: string;
  public file: UserToCreate;
  public files: File[] = [];
  public response: {'dbPath': ''}; 


  constructor(private http: HttpClient){}

  ngOnInit(){
    this.isCreate = true;
  }

  public onCreate = () => {
    this.file = {
      name: this.name,
      address: this.address,
      imgPath: this.response.dbPath
    }

    this.http.post('https://localhost:5001/api/files', this.file)
    .subscribe(res => {
      this.getFiles();
      this.isCreate = false;
    });
  }

  private getFiles = () => {
    this.http.get('https://localhost:5001/api/files')
    .subscribe(res => {
      this.files = res as File[];
    });
  }

  public returnToCreate = () => {
    this.isCreate = true;
  }

  public uploadFinished = (event) => {
    this.response = event;
  }

  public createImgPath = (serverPath: string) => {
    return `https://localhost:5001/${serverPath}`;
  }

}
