export interface File {
    id: string,
    DeliveryDate: string,
    ProductDescription: string,
    Quantity: string,
    UnitValue: string,
    TotalValue :string,
}